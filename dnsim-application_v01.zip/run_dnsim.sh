#!/bin/bash

## Matlab compiler Runtime (MCR)
export LD_LIBRARY_PATH=  			# <-- paste LD_LIBRARY_PATH path from MCRInstaller
export XAPPLRESDIR=  				# <-- paste XAPPLRESDIR path from MCRInstaller

#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:	# <-- append LD_LIBRARY_PATH path from MCRInstaller
#export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:	# <-- append XAPPLRESDIR path from MCRInstaller

./dnsim
